package mk.com.itcenter.ff;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mk.com.itcenter.ff.bean.User;
import mk.com.itcenter.ff.util.UserUtil;







public class SingUp extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.flush();
		out.close();
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		User user = new User();
		user.setFirstName(request.getParameter("firstName"));
		user.setLastName(request.getParameter("lastName"));
		user.setAddress(request.getParameter("address"));
		user.setEmailAddress(request.getParameter("eMail"));
		user.setUserName(request.getParameter("userName"));
		user.setPassword(request.getParameter("password"));

		boolean registeredUser = UserUtil.isUserregisteredSql(user
				.getUserName());

		if (!registeredUser) {
			// set user to csv
            //UserUtil.setUserToCSVFile(user);
		 	
			// set user in database
			UserUtil.setUserInDatabase(user);
			
			
			request.getSession().setAttribute("username", user.getUserName());
			request.getSession().setAttribute("firstName",
					user.getFirstName());
			request.getSession().setAttribute("lastName", user.getLastName());
			response.sendRedirect("Order.jsp");
		} else {
			response.sendRedirect("SignUp.jsp?userInUse=inUse");
		}
		out.flush();
		out.close();
	}

	public void init() throws ServletException {

	}

}
