package mk.com.itcenter.ff;

import mk.com.itcenter.ff.bean.User;
import mk.com.itcenter.ff.util.UserUtil;
import sun.applet.Main;

public class Test {
	public static void main(String[] args) {
		User user = new User();
		user.setFirstName("jovan");
		user.setLastName("bojcevski");
		user.setAddress("par");
		user.setEmailAddress("nikola@gmail.com");
		user.setUserName("joo");
		user.setPassword("kkk");
		System.out.println(UserUtil.setUserInDatabase(user));
		
	}
}
