package mk.com.itcenter.ff.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.sql.*;

import mk.com.itcenter.ff.bean.Order;
import mk.com.itcenter.ff.bean.User;





public class OrderUtil {
	private static Connection conn = null;

	private static void OpenConnectionDb() {

		try {
			String username = "root";
			String password = "";
			String url = "jdbc:mysql://localhost:3306/sendvicara";
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn = (Connection) DriverManager.getConnection(url, username,
					password);
			System.out.println("Database connection established");
		} catch (Exception e) {

			System.err.println("Cannot connect to database");
		}

	}

	private static void CloseConnectionDb() {

		if (conn != null) {

			try {
				conn.close();
				System.out.println("Database connection terminated");
			} catch (Exception e2) {

			}

		}

	}

	/**
	 * Gets the orders from csv file.
	 * 
	 * @param pPathToCSVFile
	 *            the path to csv file
	 * 
	 * @return the orders from csv file
	 */
	public static List<Order> getOrdersFromCSVFile(String pPathToCSVFile) {
		List<Order> orders = new ArrayList<Order>();

		File file = new File(pPathToCSVFile);
		try {
			BufferedReader bufRdr = new BufferedReader(new FileReader(file));
			String line = null;
			String[] param = null;
			while ((line = bufRdr.readLine()) != null) {
				param = line.split(",");
				Order order = new Order();
				order.setType(param[0]);
				if (param[1] != null && "true".equals(param[1])) {
					order.setSalad(true);
				} else {
					order.setSalad(false);
				}
				if (param[2] != null && "true".equals(param[2])) {
					order.setSal(true);
				} else {
					order.setSal(false);
				}
				if (param[3] != null && "true".equals(param[3])) {
					order.setPepper(true);
				} else {
					order.setPepper(false);
				}
				if (param[4] != null && "true".equals(param[4])) {
					order.setOregano(true);
				} else {
					order.setOregano(false);
				}
				if (param[5] != null && "true".equals(param[5])) {
					order.setChips(true);
				} else {
					order.setChips(false);
				}
				if (param[6] != null && !"".equals(param[6])) {
					order.setDrink(param[6]);
				} else {
					order.setDrink(" ");
				}
				if (param[7] != null && !"".equals(param[7])) {
					order.setUserName(param[7]);
				} else {
					order.setUserName("empty");
				}
				orders.add(order);
			}
			bufRdr.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return orders;
	}

	public static boolean setOrderInDatabase(Order order) {
		boolean result = false;

		CallableStatement calsta = null;
		String query = "{ call insertOrder(?,?,?,?,?,?,?)}";

		try {
			OpenConnectionDb();
			calsta = conn.prepareCall(query);
			
			calsta.setString(1, order.getUserName());
			calsta.setString(2, order.getType());
			calsta.setBoolean(3, order.isSal());
			calsta.setBoolean(4, order.isPepper());
			calsta.setBoolean(5, order.isOregano());
			calsta.setBoolean(6, order.isChips());
			calsta.setString(7, order.getDrink());

			ResultSet rs = calsta.executeQuery();

			CloseConnectionDb();
			result = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return result;
	}
	
	public static List<Order> getAllOrdersFromDatabase() {
		List<Order> allOrders = new ArrayList<>();

		CallableStatement calsta = null;
		String query = "{ call getAllOrders() }";

		try {
			OpenConnectionDb();
			calsta = conn.prepareCall(query);

			ResultSet rs = calsta.executeQuery();

			while(rs.next()) {
				Order order = new Order();
				
				order.setUserName(rs.getString("username"));
				order.setType(rs.getString("tip"));
				order.setSalad(rs.getBoolean("salata"));
				order.setPepper(rs.getBoolean("piper"));
				order.setChips(rs.getBoolean("pomfrit"));
				order.setOregano(rs.getBoolean("origano"));
				order.setDrink(rs.getString("sok"));
				
				allOrders.add(order);
			} 
			
			
			CloseConnectionDb();
			
			return allOrders;
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return allOrders;
	}
	
	public static List<Order> getAllOrdersFromDatabaseByUser(String username) {
		List<Order> allOrders = new ArrayList<>();

		CallableStatement calsta = null;
		String query = "{ call getAllOrdersByUser(?) }";

		try {
			OpenConnectionDb();
			calsta = conn.prepareCall(query);
			calsta.setString(1, username);
			
			ResultSet rs = calsta.executeQuery();

			while(rs.next()) {
				Order order = new Order();
				
				order.setUserName(rs.getString("username"));
				order.setType(rs.getString("tip"));
				order.setSalad(rs.getBoolean("salata"));
				order.setPepper(rs.getBoolean("piper"));
				order.setChips(rs.getBoolean("pomfrit"));
				order.setOregano(rs.getBoolean("origano"));
				order.setDrink(rs.getString("sok"));
				
				allOrders.add(order);
			} 
			
			
			CloseConnectionDb();
			
			return allOrders;
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return allOrders;
	}

	/**
	 * Sets the orders to csv file.
	 * 
	 * @param pPathToCSVFile
	 *            the path to csv file
	 * @param pOrders
	 *            the orders
	 * 
	 * @return true, if successful
	 */
	public static boolean setOrdersToCSVFile(String pPathToCSVFile,
			List<Order> pOrders) {
		boolean result = false;

		if (pPathToCSVFile == null || "".equals(pPathToCSVFile.trim())) {
			return result;
		}

		FileWriter fileWriter = null;
		BufferedWriter bw = null;
		try {
			fileWriter = new FileWriter(pPathToCSVFile);
			bw = new BufferedWriter(fileWriter);

			String content = "";

			for (Order order : pOrders) {
				content += order.getType() + ",";
				content += order.isSalad() + ",";
				content += order.isSal() + ",";
				content += order.isPepper() + ",";
				content += order.isOregano() + ",";
				content += order.isChips() + ",";
				content += order.getDrink() + ",";
				content += order.getUserName() + "\n";
			}

			bw.write(content);
			bw.flush();
			fileWriter.close();
			bw.close();
			result = true;
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}

		return result;
	}

	/**
	 * Gets the orders by user name.
	 * 
	 * @param pPathToCSVFile
	 *            the path to csv file
	 * @param userName
	 *            the user name
	 * 
	 * @return the orders by user name
	 */
	public static List<Order> getOrdersByUserName(String pPathToCSVFile,
			String userName) {
		List<Order> orderByUserName = new ArrayList<Order>();

		if (userName == null || "".equals(userName)) {
			return orderByUserName;
		}

		List<Order> orders = getOrdersFromCSVFile(pPathToCSVFile);

		for (Order order : orders) {

			if (order.getUserName().equals(userName)) {
				orderByUserName.add(order);
			}
		}

		return orderByUserName;
	}

}