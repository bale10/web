package mk.com.itcenter.ff.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import mk.com.itcenter.ff.bean.Order;
import mk.com.itcenter.ff.bean.User;
import mk.com.itcenter.ff.constants.FastFoodStaticVariables;





public class UserUtil {	
	private static	Connection conn = null ;
	private static void OpenConnectionDb(){
		
		
		try {
			String username = "root";
			String password = "";
			String url = "jdbc:mysql://localhost:3306/sendvicara";
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn = (Connection) DriverManager.getConnection(url, username, password);
			System.out.println("Database connection established");
		} catch (Exception e) {
	
			System.err.println("Cannot connect to database");
		}
		
		
	}
	private static void CloseConnectionDb(){

		

		if(conn != null) {
			
			try {
				conn.close();
				System.out.println("Database connection terminated");
			} catch (Exception e2) {

			}
			
		}
		
	}
	
	
	public static boolean isUserregisteredSql(String username){
		
		boolean status = false; 
		
		CallableStatement calsta = null;
		String query = "{ call getAllUsers(?) }";
		
		try {
			OpenConnectionDb();
			calsta = conn.prepareCall(query);
			calsta.setString(1, username);
			
			ResultSet rs = calsta.executeQuery();
			
			while (rs.next()){
				String ime = rs.getString(1);
				if (ime !=  null ){
					status = true;
					CloseConnectionDb();
					break;
				}
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return status;	
		
	} 
	public static boolean setUserInDatabase(User user) {
		boolean result = false;

		CallableStatement calsta = null;
		String query = "{ call insertUser(?,?,?,?,?,?)}";
		
		try {
			OpenConnectionDb();
			
			calsta = conn.prepareCall(query);
			
			calsta.setString(1, user.getFirstName());
			calsta.setString(2, user.getLastName());
			calsta.setString(3, user.getAddress());
			calsta.setString(4, user.getEmailAddress());
			calsta.setString(5, user.getUserName());
			calsta.setString(6, user.getPassword());
			
			calsta.executeQuery();
			 
			 CloseConnectionDb();
			 result = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}
	/**

	 * Checks if is user registered.
	 * 
	 * @param userNmae the user name
	 * @param password the password
	 * 
	 * @return true, if is user registered
	 */
	public static boolean isUserRegistered(String userNmae, String password){
		boolean status = false;		
		List<User> accounts = getUserFromCSVFile(FastFoodStaticVariables.PATH_TO_CSV_FILE_FOR_USERS);		
		for (User account : accounts) {
			if (account.getUserName().equals(userNmae) && account.getPassword().equals(password)){
				status = true;
				break;
			}
		}		
		return status;
	}

	/**
	 * Gets the accounts from csv file.
	 * 
	 * @param pPathToCSVFile the path to csv file
	 * 
	 * @return the accounts from csv file
	 */
	private static List<User> getUserFromCSVFile(String pPathToCSVFile){
		List<User> accounts = new ArrayList<User>();
		File file = new File(pPathToCSVFile);
		try {
			BufferedReader bufRdr  = new BufferedReader(new FileReader(file));
			String line = null;
			String[] param = null;
			while((line = bufRdr.readLine()) != null){
				param = line.split(",");
				User account = new User(param[0], param[1], param[2], param[3], param[4], param[5]);
				accounts.add(account);
			}
			bufRdr.close();
		} catch (IOException e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
		return accounts;
	}

//	public static List<User> getUserFromDatabase(){
//		List<User> accounts = new ArrayList<User>();
//		File file = new File(pPathToCSVFile);
//		try {
//			BufferedReader bufRdr  = new BufferedReader(new FileReader(file));
//			String line = null;
//			String[] param = null;
//			while((line = bufRdr.readLine()) != null){
//				param = line.split(",");
//				User account = new User(param[0], param[1], param[2], param[3], param[4], param[5]);
//				accounts.add(account);
//			}
//			bufRdr.close();
//		} catch (IOException e) {
//			// TODO: handle exception
//			System.out.println(e.getMessage());
//		}
//		return accounts;
//	}
	
	/**
	 * If user exist returns the user if not returns null 
	 * 
	 * @param userNmae the user name
	 * @param password the password
	 * 
	 * @return the user
	 */
	public static User getRegisteredUserFromCsv(String userName, String password){
		List<User> accounts = getUserFromCSVFile(FastFoodStaticVariables.PATH_TO_CSV_FILE_FOR_USERS);		

		for (User account : accounts) {
			if (account.getUserName().equalsIgnoreCase(userName) && account.getPassword().equals(password)){
				return account;
			}
		}		
		return null;
	}
	
	public static User getRegisteredUserFromDatabase(String username, String password){
		User user = null;
		
		CallableStatement calsta = null;
		String query = "{ call login(?,?) }";
		
		try {
			OpenConnectionDb();
			calsta = conn.prepareCall(query);
			
			calsta.setString(1, username);
			calsta.setString(2, password);
			
			ResultSet rs = calsta.executeQuery();
			
			while (rs.next()){
				user = new User();
				
				user.setUserName(rs.getString("username"));
				user.setFirstName(rs.getString("first_name"));
				user.setLastName(rs.getString("last_name"));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return user;	
	}


	/**
	 * Gets the accounts from csv file.
	 * 
	 * @return the accounts from csv file
	 */
	public static List<User> getAllUsers()
	{
		List<User> accounts = getUserFromCSVFile(FastFoodStaticVariables.PATH_TO_CSV_FILE_FOR_USERS);
		if (accounts == null)
		{
			accounts = new ArrayList<User>();			
		}
		return accounts;
	}
	
	public static List<User> getAllUsersFromDatabase()
	{
		List<User> users = new ArrayList<User>();
		
		CallableStatement calsta = null;
		String query = "{ call getAlUser() }";
		
		try {
			OpenConnectionDb();
			calsta = conn.prepareCall(query);
			
			ResultSet rs = calsta.executeQuery();
			
			while (rs.next()){
				User user = new User();
				
				user.setUserName(rs.getString("username"));
				user.setFirstName(rs.getString("first_name"));
				user.setLastName(rs.getString("last_name"));
				
				users.add(user);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return users;
	}


	/**
	 * Sets the user to csv file.
	 * 
	 * @param user the user
	 * 
	 * @return true, if successful
	 */
	public static boolean setUserToCSVFile(User user){
		boolean result = false;
		String pPathToCSVFile = FastFoodStaticVariables.PATH_TO_CSV_FILE_FOR_USERS;
		if (pPathToCSVFile == null||"".equals(pPathToCSVFile.trim())){
			return result;
		}
		FileWriter fileWriter = null;		
		BufferedWriter bw = null;
		try	{
			fileWriter = new FileWriter(pPathToCSVFile, true);			
			bw = new BufferedWriter(fileWriter);			
			String content = "";			
			content += user.getFirstName() + ",";
			content += user.getLastName() + ",";
			content += user.getAddress() + ",";
			content += user.getEmailAddress() + ",";
			content += user.getUserName() + ",";				
			content += user.getPassword();
			bw.write(content);	
			bw.newLine();
			bw.flush();	
			bw.close();
			fileWriter.close();			
			result = true;
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return result;
	}
	
	/**
	 * Checks if is username used.
	 * 
	 * @param userNmae the user nmae
	 * @param password the password
	 * 
	 * @return true, if is username used
	 */
	public static boolean isUsernameUsed(String userNmae, String password){
		boolean status = false;		
		List<User> accounts = getUserFromCSVFile(FastFoodStaticVariables.PATH_TO_CSV_FILE_FOR_USERS);		
		for (User account : accounts) {
			if (account.getUserName().equals(userNmae)){
				status = true;
				break;
			}
		}		
		return status;
	}
	public static User getRegisteredUser(Object parameter, Object parameter2) {
		// TODO Auto-generated method stub
		return null;
	}

}