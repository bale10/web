package mk.com.itcenter.ff.constants;

public interface FastFoodStaticVariables {

	public static final String PATH_TO_ROOT_LOCATION = "C:/Users/bale/Desktop/New folder/fastfood-web";

	public static final String PATH_TO_RESOURCE_FILES = "/src/mk/com/itcenter/ff/resource";

	public static final String PATH_TO_CSV_FILE_FOR_USERS = PATH_TO_ROOT_LOCATION
			+ PATH_TO_RESOURCE_FILES + "Users.csv";

	public static final String PATH_TO_CSV_FILE_ORDERS = PATH_TO_ROOT_LOCATION
			+ PATH_TO_RESOURCE_FILES + "Orders.csv";
}
