package mk.com.itcenter.ff;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mk.com.itcenter.ff.bean.User;
import mk.com.itcenter.ff.util.UserUtil;







public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.flush();
		out.close();
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		// get user from csv
	//User user = UserUtil.getRegisteredUserFromCsv(request.getParameter("user"),
				//request.getParameter("pass"));
		
		//get user from database
		User user = UserUtil.getRegisteredUserFromDatabase(request.getParameter("user"),
				request.getParameter("pass"));

		if (user != null) {
			request.getSession().setAttribute("username", user.getUserName());
			request.getSession().setAttribute("firstName", user.getFirstName());
			request.getSession().setAttribute("lastName", user.getLastName());
			request.getSession().setAttribute("invalidLogin", false);
			response.sendRedirect("Order.jsp");
		} else {
			response.sendRedirect("Login.jsp?isLoginUser=false");
			return;
		}
		out.flush();
		out.close();
	}

}
