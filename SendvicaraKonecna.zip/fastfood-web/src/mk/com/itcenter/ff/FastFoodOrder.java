package mk.com.itcenter.ff;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mk.com.itcenter.ff.bean.Order;
import mk.com.itcenter.ff.constants.FastFoodStaticVariables;
import mk.com.itcenter.ff.util.OrderUtil;







public class FastFoodOrder extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 * 
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request
	 *            the request send by the client to the server
	 * @param response
	 *            the response send by the server to the client
	 * @throws ServletException
	 *             if an error occurred
	 * @throws IOException
	 *             if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		out.flush();
		out.close();
	}

	/**
	 * The doPost method of the servlet. <br>
	 * 
	 * This method is called when a form has its tag value method equals to
	 * post.
	 * 
	 * @param request
	 *            the request send by the client to the server
	 * @param response
	 *            the response send by the server to the client
	 * @throws ServletException
	 *             if an error occurred
	 * @throws IOException
	 *             if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		Order order = new Order();
		
		if (request.getSession().getAttribute("username") != null) {
			order.setUserName(request.getSession().getAttribute("username")
					.toString());
		} else {
			return;
		}

		if (request.getParameter("vidHrana") != null) {
			order.setType(request.getParameter("vidHrana"));
		}

		if (request.getParameter("salata") != null
				&& "yes".equals(request.getParameter("salata"))) {
			order.setSalad(true);
		} else {
			order.setSalad(false);
		}

		if (request.getParameter("pomfrit") != null
				&& "yes".equals(request.getParameter("pomfrit"))) {
			order.setChips(true);
		} else {
			order.setChips(false);
		}

		if (request.getParameter("zaciniSol") != null) {
			order.setSal(true);
		}

		if (request.getParameter("zaciniPiper") != null) {
			order.setPepper(true);
		}

		if (request.getParameter("zaciniOrigano") != null) {
			order.setOregano(true);
		}

		if (request.getParameter("toppings") != null) {
			order.setDrink(request.getParameter("toppings"));
		}

		boolean statusFromOrder = false;

		//List<Order> orders = OrderUtil
		//	.getOrdersFromCSVFile(FastFoodStaticVariables.PATH_TO_CSV_FILE_ORDERS);
		//if (order != null && orders != null) {
		//	orders.add(order);
		//statusFromOrder = OrderUtil.setOrdersToCSVFile(
			//FastFoodStaticVariables.PATH_TO_CSV_FILE_ORDERS, orders);
				//	}
		
	statusFromOrder = OrderUtil.setOrderInDatabase(order);
		
		if (statusFromOrder) {
			out.println("Narachkata e uspeshno izvrshena");
		} else {
			out.println("Narachkata ne e uspeshno izvrshena");
		}

		out.println("<br>");
		out.println("<br>");
		out.println("<br>");
		out.println("<br>");
		out.println("<button type=\"button\" onclick=\"javascript: window.location='Order.jsp'\">Nova narachka</button>");

		out.flush();
		out.close();
	}

	/**
	 * Initialization of the servlet. <br>
	 * 
	 * @throws ServletException
	 *             if an error occurs
	 */
	public void init() {

	}

}
